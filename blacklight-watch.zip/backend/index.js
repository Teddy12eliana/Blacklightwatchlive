const express = require('express');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

app.get('/api/alerts', (req, res) => {
  res.json({
    status: "Active",
    regions: ["Middle East", "Eastern Europe"],
    riskLevel: "High",
    message: "Ongoing conflict detected in multiple regions. Monitor closely."
  });
});

app.listen(PORT, () => {
  console.log(`Blacklight backend running on port ${PORT}`);
});